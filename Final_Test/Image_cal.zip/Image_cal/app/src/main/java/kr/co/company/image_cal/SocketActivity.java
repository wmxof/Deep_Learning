package kr.co.company.image_cal;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Environment;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.Socket;

public class SocketActivity extends AppCompatActivity {

    private static final String SERVER_IP = "192.168.0.23";

    private static final int SERVER_PORT = 7777;

    String fileName = "my_drawing.png";

    // SDCard(ExternalStorage) : 외부저장공간
    // 접근하려면 반드시 AndroidManifest.xml에 권한 설정을 한다.
    File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "MyDrawings");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_socket);


        File file = new File(dir, fileName);

        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(file);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        mBitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
        fos.close();




        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), file);
        sendImageToServer(bitmap);
    }
    public byte[] convertToBytes(Bitmap bitmap){
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        return stream.toByteArray();
    }

    public void sendImageToServer(Bitmap bitmap){
        byte[] imageBytes = convertToBytes(bitmap);

        new Thread(new Runnable(){
            @Override
            public void run(){
                try {
                    Socket socket = new Socket(SERVER_IP, SERVER_PORT);
                    DataOutputStream dataOutputStream = new DataOutputStream(socket.getOutputStream());
                    dataOutputStream.writeInt(imageBytes.length);
                    dataOutputStream.write(imageBytes);

                    dataOutputStream.close();
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }
}