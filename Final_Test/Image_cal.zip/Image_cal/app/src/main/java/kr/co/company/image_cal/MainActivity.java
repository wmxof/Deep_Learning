package kr.co.company.image_cal;
//
//import androidx.appcompat.app.AppCompatActivity;
//import android.content.Context;
//import android.graphics.Bitmap;
//import android.graphics.Canvas;
//import android.graphics.Color;
//import android.graphics.Paint;
//import android.graphics.Path;
//import android.graphics.Point;
//import android.os.Bundle;
//import android.os.Environment;
//import android.util.Log;
//import android.view.MotionEvent;
//import android.view.View;
//import android.widget.Button;
//import android.widget.LinearLayout;
//import android.widget.RadioGroup;
//import android.widget.Toast;
//import android.graphics.Bitmap.CompressFormat;
//
//import java.io.File;
//import java.io.FileOutputStream;
//import java.util.ArrayList;
//
//public class MainActivity extends AppCompatActivity {
//    private MyPaintView myView;
//    int count = 0;
//    public static float mStrokeWidth = 1;
//
//    private MyPaintView mDrawView = new MyPaintView(this);
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//        setTitle("계산기 그림판");
//        myView = new MyPaintView(this);
//
//        ((LinearLayout) findViewById(R.id.paintLayout)).addView(myView);
//
//        Button btnTh = findViewById(R.id.btnSave);
//        btnTh.setOnClickListener((new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                // 1. 캐쉬(Cache)를 허용시킨다.
//                // 2. 그림을 Bitmap 으로 저장.
//                // 3. 캐쉬를 막는다.
//                mDrawView.setDrawingCacheEnabled(true);    // 캐쉬허용
//                // 캐쉬에서 가져온 비트맵을 복사해서 새로운 비트맵(스크린샷) 생성
//                Bitmap screenshot = Bitmap.createBitmap(mDrawView.getDrawingCache());
//                mDrawView.setDrawingCacheEnabled(false);   // 캐쉬닫기
//
//                // SDCard(ExternalStorage) : 외부저장공간
//                // 접근하려면 반드시 AndroidManifest.xml에 권한 설정을 한다.
//                File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "pict");
//                // 폴더가 있는지 확인 후 없으면 새로 만들어준다.
//                if(!dir.exists())
//                    dir.mkdirs();
//                FileOutputStream fos;
//
//                try {
//
//                    fos = new FileOutputStream(new File(dir, "my.png"));
//                    screenshot.compress(CompressFormat.PNG, 100, fos);
//                    fos.close();
//                    Toast.makeText(getApplicationContext(), "저장 성공", Toast.LENGTH_SHORT).show();
//
//
//
//                } catch (Exception e) {
//                    Log.e("phoro","그림저장오류",e);
//                    Toast.makeText(getApplicationContext(), "저장 실패", Toast.LENGTH_SHORT).show();
//
//                }
//
//            }
//        }));
//
//        ((Button)findViewById(R.id.btnCancle)).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                myView.mBitmap.eraseColor(Color.TRANSPARENT);
//                myView.invalidate();
//            }
//        });
//    }
//
//    private static class MyPaintView extends View implements View.OnTouchListener{
//        private Bitmap mBitmap;
//        private Canvas mCanvas;
//        private Path mPath;
//        private Paint mPaint;
//
//        public MyPaintView(Context context) {
//            super(context);
//            mPath = new Path();
//            mPaint = new Paint();
//            mPaint.setColor(Color.BLACK);
//            mPaint.setAntiAlias(true);
//            mPaint.setStrokeWidth(20);
//            mPaint.setStyle(Paint.Style.STROKE);
//        }
//
//        @Override
//        protected void onSizeChanged(int w, int h, int oldw, int oldh) {
//            super.onSizeChanged(w, h, oldw, oldh);
//            mBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
//            mCanvas = new Canvas(mBitmap);
//        }
//
//        @Override
//        protected void onDraw(Canvas canvas) {
//            canvas.drawBitmap(mBitmap, 0, 0, null); //지금까지 그려진 내용
//            canvas.drawPath(mPath, mPaint); //현재 그리고 있는 내용
//        }
//
//        @Override
//        public boolean onTouchEvent(MotionEvent event) {
//            int x = (int) event.getX();
//            int y = (int) event.getY();
//            switch (event.getAction()) {
//                case MotionEvent.ACTION_DOWN:
//                    mPath.reset();
//                    mPath.moveTo(x, y);
//                    break;
//                case MotionEvent.ACTION_MOVE:
//                    mPath.lineTo(x, y);
//                    break;
//                case MotionEvent.ACTION_UP:
//                    mPath.lineTo(x, y);
//                    mCanvas.drawPath(mPath, mPaint); //mBitmap 에 기록
//                    mPath.reset();
//                    break;
//            }
//            this.invalidate();
//            return true;
//        }
//
//        @Override
//        public boolean onTouch(View view, MotionEvent motionEvent) {
//            return false;
//        }
//    }
//}

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Bundle;
import android.os.Environment;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.graphics.Bitmap.CompressFormat;

import java.io.File;
import java.io.FileOutputStream;

public class MainActivity extends AppCompatActivity {
    private MyPaintView myView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("간단한 그림판");

        LinearLayout paintLayout = findViewById(R.id.paintLayout);
        myView = new MyPaintView(this);
        paintLayout.addView(myView);

        Button btnSave = findViewById(R.id.btnSave);
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myView.saveDrawing();
            }
        });
    }

    private class MyPaintView extends View {
        private Bitmap mBitmap;
        private Canvas mCanvas;
        private Path mPath;
        private Paint mPaint;

        public MyPaintView(Context context) {
            super(context);
            mPath = new Path();
            mPaint = new Paint();
            mPaint.setColor(Color.BLACK);
            mPaint.setAntiAlias(true);
            mPaint.setStrokeWidth(20);
            mPaint.setStyle(Paint.Style.STROKE);
        }

        @Override
        protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            mBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            mCanvas = new Canvas(mBitmap);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            canvas.drawBitmap(mBitmap, 0, 0, null);
            canvas.drawPath(mPath, mPaint);
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            int x = (int) event.getX();
            int y = (int) event.getY();
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    mPath.reset();
                    mPath.moveTo(x, y);
                    break;
                case MotionEvent.ACTION_MOVE:
                    mPath.lineTo(x, y);
                    break;
                case MotionEvent.ACTION_UP:
                    mPath.lineTo(x, y);
                    mCanvas.drawPath(mPath, mPaint);
                    mPath.reset();
                    break;
            }
            invalidate();
            return true;
        }

        public void saveDrawing() {
            String fileName = "my_drawing.png";

            // SDCard(ExternalStorage) : 외부저장공간
            // 접근하려면 반드시 AndroidManifest.xml에 권한 설정을 한다.
            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "MyDrawings");
            if (!dir.exists())
                dir.mkdirs();

            File file = new File(dir, fileName);
            try {
                FileOutputStream fos = new FileOutputStream(file);
                mBitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
                fos.close();
                Toast.makeText(getApplicationContext(), "그림이 저장되었습니다.", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(getApplicationContext(), "그림 저장에 실패했습니다.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}