package kr.co.company.socket;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class MainActivity extends AppCompatActivity {

    private static final String SERVER_IP = "192.168.0.23";
    private static final int SERVER_PORT = 7777;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.fruits);
        sendImageToServer(bitmap);
    }

    public byte[] convertToBytes(Bitmap bitmap){
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        return stream.toByteArray();
    }

    public void sendImageToServer(Bitmap bitmap){
        byte[] imageBytes = convertToBytes(bitmap);

        new Thread(new Runnable(){
            @Override
            public void run(){
                try {
                    Socket socket = new Socket(SERVER_IP, SERVER_PORT);
                    DataOutputStream dataOutputStream = new DataOutputStream(socket.getOutputStream());
                    dataOutputStream.writeInt(imageBytes.length);
                    dataOutputStream.write(imageBytes);

                    dataOutputStream.close();
                    socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }
}


//import android.Manifest;
//import android.annotation.SuppressLint;
//import android.content.pm.PackageManager;
//import android.graphics.Bitmap;
//import android.graphics.BitmapFactory;
//import android.os.AsyncTask;
//import android.os.Bundle;
//import android.util.Log;
//import android.view.View;
//import android.widget.Button;
//import android.widget.EditText;
//import android.widget.ImageView;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.core.app.ActivityCompat;
//import androidx.core.content.ContextCompat;
//
//import java.io.ByteArrayOutputStream;
//import java.io.DataInputStream;
//import java.io.DataOutputStream;
//import java.io.IOException;
//import java.io.OutputStream;
//import java.net.Socket;
//
//public class MainActivity extends AppCompatActivity {
//    private static final String TAG = "MainActivity";
//    private static final int REQUEST_PERMISSION = 1;
//    private static final String SERVER_IP = "192.168.0.23";
//    private static final int SERVER_PORT = 7777;
//    private Button sendButton;
//    private ImageView imageView;
//    private Bitmap imageBitmap;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//
//        sendButton = findViewById(R.id.send_button);
//        imageView = findViewById(R.id.imageView);
//
//
//
//
//
//
//
//
//    }
//    public byte[] convertToBytes(Bitmap bitmap){
//        ByteArrayOutputStream stream = new ByteArrayOutputStream();
//        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
//        return stream.toByteArray();
//    }
//    public void sendImageToServer(Bitmap bitmap){
//        byte[] imageBytes = convertToBytes(bitmap);
//
//        new Thread(new Runnable() {
//            @Override
//            public void run() {
//                try{
//                    Socket socket = new Socket(SERVER_IP, SERVER_PORT);
//
//                    DataOutputStream dataOutputStream = new DataOutputStream(socket.getOutputStream());
//                    dataOutputStream.writeInt(imageBytes.length);
//                    dataOutputStream.write(imageBytes);
//
//                    dataOutputStream.close();
//                    socket.close();
//                }catch(IOException e){
//                    e.printStackTrace();
//                }
//            }
//        }).start();
//    }
//}